# LiteLoaderQQNT - kill-update

LiteLoaderQQNT插件，完全屏蔽更新推送（QQ会认为自己是最新版）。
使用前需要安装[LiteLoaderQQNT](https://github.com/mo-jinran/LiteLoaderQQNT)，并在QQNT新版上使用。
目前已适配高版本QQ，建议所有用户更新。

## 使用方法

直接在Github页面上Download Zip，然后在LiteLoaderQQNT配置界面中选择插件压缩包导入即可
也可以使用插件商店类应用安装，如 https://github.com/ltxhhz/LL-plugin-list-viewer

**版本不兼容提示**：从0.1.5起，插件已适配1.0版本以上`LiteLoaderQQNT`框架，同时不再兼容旧版框架，请遵循[安装方法](https://liteloaderqqnt.github.io/guide/install.html)更新框架。

会导致即使手动检查更新也提示是最新版

<img width="881" height="409" alt="image" src="https://github.com/user-attachments/assets/ed8e093f-aa6e-43d9-8d5b-81561aaa1bdc" />

## 协议及免责

MIT | 禁止用于任何非法用途，插件开发属学习与研究目的，仅自用，未提供给任何第三方使用。任何不当使用导致的任何侵权问题责任自负。
