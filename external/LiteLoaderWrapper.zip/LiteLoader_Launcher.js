require('F:\\launcherNormal\\LL\\src\\init.js');
require('./application/app_launcher/index.js');
