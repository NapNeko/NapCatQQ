require('C:\\Users\\nanae\\Downloads\\NapCat.Framework.Windows.Once\\LL\\src\\init.js');
require('./application/app_launcher/index.js');
